
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');



const app = express();
app.use(cors());

const port = 3001;


// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/Sample', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => {
    console.log('Connected to MongoDB'); // Log when the connection is successful
  })
  .catch((error) => {
    console.error('MongoDB connection error:', error); // Log if there's an error during connection
  });


const NameSchema = new mongoose.Schema({
  tag: String,
});

const TagModel = mongoose.model('Tag', NameSchema);

app.use(bodyParser.json());

// Route to save a tag
app.post('/api/name', async (req, res) => {
  try {
    const { tag } = req.body;

    // Create a new tag document and save it to MongoDB
    const newTag = new TagModel({ tag });
    await newTag.save();

    res.status(201).json({ message: 'Tag saved successfully' });
  } catch (error) {
    console.error('Error saving tag:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
