import React, { useState } from 'react';

import axios from 'axios';

function App1() {
  const [tag, setTag] = useState('');

  const handleTagChange = (e) => {
    setTag(e.target.value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:3001/api/name', { tag });
      console.log('Tag saved successfully:', response.data);
      setTag('');
    } catch (error) {
      console.error('Error saving tag:', error);
    }
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '350px' }}>
      <h2>"Integrated frontend and backend using React for the UI and Express with MongoDB for the server and database."</h2> <br/>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter your name..."
          value={tag}
          onChange={handleTagChange}
          style={{
            padding: '10px',
            fontSize: '16px',
            border: '2px solid #007bff',
            borderRadius: '5px',
          }}
        /> <br/> <br/>
        <button
          type="submit"
          style={{
            background: '#007bff',
            color: 'white',
            border: 'none',
            borderRadius: '5px',
            padding: '10px 20px',
            marginLeft: '10px',
            cursor: 'pointer',
          }}
        >
          Submit
        </button>
      </form>
    </div>
  );
}

export default App1;
